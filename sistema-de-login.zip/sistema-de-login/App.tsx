import React, {useState} from 'react';
import { Text, View, StyleSheet, Image, TextInput, Button, Alert, Pressable } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
//acima tem os imports que utilizei. A principio iria usar o react native usando o expo na minha máquina, mas tinh que ficar baixando muitos modulos e desisti kkk, por isso fiz pelo snack, pois encontrei um video na gringa que explicava como usuar o navigate

function Home({ navigation }) {

  return (
    
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#1a1d29'}}>

      <Image  
        source={require('./assets/logo-disney.png')}
        style={{ width: 190, height: 190 , alignSelf: "center"}}
      />

      <Text style={{color: "#ffffff", padding: 4, fontSize: 20, textAlign: 'center', fontFamily: 'Trebuchet MS, sans-serif',}}>
        Central da Ajuda 
      </Text>
      
      <Pressable
        onPress={() => navigation.navigate('Login')}
        style={{ backgroundColor: '#1274cf', padding: 10, marginBottom: 10, marginTop: 10 , width: 'auto', borderRadius: 7}}>
      
        <Text style={{color: '#ffffff',fontFamily: 'Trebuchet MS, sans-serif' }}> ENTRAR </Text>
        
      </Pressable>

      <Pressable
        onPress={() => navigation.navigate('Story')}
        style={{ backgroundColor: '#1274cf', padding: 10, width: 'auto',borderRadius: 7 }}>
      
        <Text style={{color: '#ffffff',fontFamily: 'Trebuchet MS, sans-serif' }} > SOBRE </Text>

      </Pressable>

    </View>
  );
}

function Login({ navigation }) {

  const [email, setEmail] = useState("")
  const [senha, setSenha] = useState("")

   function entrar(){

      if(email == "admin@gmail.com" && senha =="admin123"){
        Alert.alert("Você está logado!")
        navigation.navigate('Logado')
    /*
      }else if(email == "admin@gmail.com" && senha == " "){
        Alert.alert("Todos os campos devem ser preenchidos! Tente Novamente.")
        

      }else if(email == " " && senha == "admin123"){
        Alert.alert("Todos campos devem ser preenchidos! Tente Novamente.")
        

      }else if(email == " " && senha == " "){
        Alert.alert("Os campos devem ser preenchidos! Tente Novamente.")
        

      }else if(email != "admin@gmail.com " && senha != "admin123"){
        Alert.alert("Usuário não cadastrado!")
        navigation.navigate('Erro')
        */
        //professor eu tentei fazer os osutros parametros mas infelizmente estava dando erro, estrava puxando sempre este ultimo paramentro de usuario não encontrado;

      }else{
        Alert.alert("Usuário não cadastrado!")
        navigation.navigate('Erro')
      }
     
   }

  return (

    <View style={styles.container} >
    
      <Image  
        source={require('./assets/logo-disney.png')}
        style={{ width: 190, height: 190 , alignSelf: "center"}}
      />

      <Text style={styles.h3}>Entre com seu email</Text>

      <TextInput
        style={styles.input}
        placeholder=" "
        onChangeText={email=>setEmail(email)}
      
      />

      <Text > </Text>

      <Text style={styles.h3}>Digite sua senha</Text>

      <TextInput
        style={styles.input}
        placeholder=""
        secureTextEntry={true}
        onChangeText={senha=>setSenha(senha)}        

      />

      <Text > </Text>

      <Button style={styles.entrar}        
        title="Entrar"
        onPress={() => entrar()}
      />

      <Text > </Text>

      <Text style={styles.cadastro}>Não tem Disney+? ASSINAR</Text>

    </View>
  );
}

function Story() {

  return (

    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center',  backgroundColor: '#1a1d29' }}>

      <Image  
          source={require('./assets/img_disney1.png')}
          style={{ width: 250, height: 200 , alignSelf: "center", borderRadius: 15, marginTop: 10}}
        />

      <Text> </Text>

      <Text style={styles.textinho}>A The Walt Disney Company foi fundada em 1923 pelos irmãos Walt Disney e Roy Oliver Disney. A empresa nasceu como pioneira no mercado de animação e ao longo das décadas ampliou sua participação na indústria, tornando-se a gigante do entretenimento que todos conhecem. O personagem mais famoso da companhia é Mickey Mouse, que estrelou o primeiro filme sonoro da Disney, Steamboat Willie, em 18 novembro de 1928.</Text>

      <Text> </Text>

      <Text style={styles.textinho}> De acordo com a The Walt Disney Company, seu principal objetivo é "tornar as pessoas felizes". Para isso, a companhia tem como valores a "criatividade", "sonhos" e "imaginação", além da atenção aos detalhes para a preservação da "magia" da Disney.</Text>

      <Text> </Text>

      <Image  
        source={require('./assets/logo-disney.png')}
        style={{ width: 190, height: 190 , alignSelf: "center"}}
      />

      <Text> </Text>

      <Text style={styles.textinho}>Disney+ (pronunciado como Disney Plus) é um serviço de streaming over-the-top de vídeo sob demanda por assinatura de propriedade e operado pela divisão Media and Entertainment Distribution da The Walt Disney Company. </Text>
        
      <Text style={styles.textinho}>O serviço oferece principalmente filmes e séries de televisão produzidos pela The Walt Disney Studios e Walt Disney Television, com hubs de conteúdo dedicados para marcas como Disney, Pixar, Marvel, Star Wars, National Geographic e incluindo Star em alguns países. Filmes e séries de televisão originais também são distribuídos no Disney+.</Text>

      <Text> </Text>
      <Text> </Text>
      <Text> </Text>

    </View>
  );
}

function Logado({ navigation }) {

 
  return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center',  backgroundColor: '#1a1d29' }}>

        <Image  
          source={require('./assets/img_disney2.png')}
          style={{ width: 250, height: 200 , alignSelf: "center", borderRadius: 15, marginTop: 10}}
        />

        <Text> </Text>

        <Text style={styles.textinho} > Você está logado!</Text>

        <Text> </Text>
        
        <Text style={styles.textinho}> Agora pode desfrutar dos maravilhosas obras da Disney+!</Text>

      </View>
  );
}

function Erro({ navigation }) {

 
  return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center',  backgroundColor: '#1a1d29' }} >

        <Image  
            source={require('./assets/img_disney3.png')}
            style={{ width: 250, height: 200 , alignSelf: "center", borderRadius: 15, marginTop: 10}}
        />

        <Text> </Text>

        <Text style={styles.textinho}>Infelizmente algo deu errado!</Text>

        <Text> </Text>
      
        <Text style={styles.textinho}>Algumas dicas que pode te ajudar:</Text>

        <Text> </Text>

        <Text style={styles.textinho}>Verifique se a senha e email estão corretos.</Text>
        <Text style={styles.textinho}>Os emails devem conter um @ e .com ao final.</Text>
        <Text style={styles.textinho}>As senhas devem conter letras e numeros.</Text>

        <Text> </Text>

        <Text style={styles.textinho}>Caso o erro persistir, entre em contato com a central de ajuda.</Text>

      </View>
  );
}


const Stack = createStackNavigator();

function App() {

  return (

    <NavigationContainer>

      <Stack.Navigator>

        <Stack.Screen name="Home" component={Home} />
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="Story" component={Story} />
        <Stack.Screen name="Logado" component={Logado} />
        <Stack.Screen name="Erro" component={Erro} />

      </Stack.Navigator>

    </NavigationContainer>
      
  );
}

export default App;

const styles = StyleSheet.create({

  container: {
    flex: 1,
    justifyContent: 'center',  
    padding: 8,
    backgroundColor: '#1a1d29',
  },

  input: {
    marginTop: 20,
    width: 'auto',
    backgroundColor: '#343440',
    fontSize: 16,
    fontWeight: 'bold',
    borderRadius: 5,
    color: '#ffffff',
    padding: 8,
    opacity: 0.6,
   
  },

  h3: {
    color: "white",
    padding: 4,
    fontSize: 20,
    textAlign: 'left',
    fontFamily: 'Trebuchet MS, sans-serif',
  },

  entrar: {
    widht:'auto',
    textAlign: 'center',
    fontSize: 16,
    fontWeight: 'bold',
    borderRadius: 5,
    fontFamily: 'Trebuchet MS, sans-serif',
      
  },
  
  cadastro: {
    textAlign: 'center',
    color: '#ffffff',
    fontSize: 11,
    fontFamily: 'Trebuchet MS, sans-serif',

  },

  textinho: {
    color: '#ffffff',
    fontFamily: 'Trebuchet MS, sans-serif',
    textAlign: 'center' 

  }

  });
