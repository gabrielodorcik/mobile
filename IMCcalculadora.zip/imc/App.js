//executando os imports
import React from "react";
import { StyleSheet, Text, TextInput, View, Button, Alert, ImageBackground } from "react-native";
import assets from './assets/imageIMC.png'; 

//segundo algumas fontes eu achei melhor usar esse método com construtor
export default class App extends React.Component {
  

  constructor(props) {

    super(props);
      this.state = {

        altura: 0,
        massa: 0,
        resultado: 0,
        resultTexto: "Insira os valores!"

    };

      this.calcular = this.calcular.bind(this);
  }

//declarando a função no qual irá utilizar os valores digitados pelo usuário
  calcular() {

    this.state.resultado =
    this.state.massa / (this.state.altura * this.state.altura);

// a parte mais chata do código kkk algumas fontes na internet propuseram um meio 
//com menos ifs e elses mas não havia entendido bem então fiz desse modo mesmo

    if (this.state.massa < 10 || this.state.massa > 200) {

      console.log(this.state.massa);

      Alert.alert("Encontramos um erro...", "Verifique se o valor do peso está correto!");
      this.state.resultTexto = "Verifique o valor do peso!";
      this.state.resultado = 0;

    } else if (this.state.altura < 1 || this.altura > 3) {

      Alert.alert("Encontramos um erro...", "Verifique se o valor da altura está correta!");
      this.state.resultTexto = "Verifique o valor da altura.";
      this.state.resultado = 0;

    } else if (isNaN(this.state.altura)) {

      Alert.alert("Encontramos um erro...", "Altura deve ser separada por '.' \nEx: 1.56");
      this.state.resultTexto = "Verifique o valor da altura, novamente";
      this.state.resultado = 0;

    } else if (this.state.resultado < 18.5) {

      this.state.resultTexto = "Abaixo do peso!";

    } else if (this.state.resultado < 25) {

      this.state.resultTexto = "Saudável!";

    } else if (this.state.resultado < 30) {

      this.state.resultTexto = "Sobrepeso!";

    } else if (this.state.resultado < 35) {

      this.state.resultTexto = "Obesidade Grau I!";

    } else if (this.state.resultado < 40) {
      this.state.resultTexto = "Obesidade Grau II!";

    } else {
      this.setState.resultTexto = "Obesidade Grau III ou Mórbida";
    }
    this.setState(this.state);
  }
// aqui estão os comandos para o usuário inserir os valores

  render() {
    return (

      <View style={styles.container}>
      <ImageBackground source={require('./assets/imageIMC.png')} style={styles.imageBackground}/> 
        <View style={styles.entrada}>
          
          <TextInput
            autoCapitalize="none"
            placeholder="Insira o seu peso:"
            keyboardType="numeric"
            style={styles.input}
            onChangeText={massa => {

              this.setState({ massa });
              }
            }
          />

          <TextInput
            autoCapitalize="none"
            placeholder="Insira a sua altura:"
            keyboardType="numeric"
            style={styles.input}
            onChangeText={altura => {
              this.setState({ altura });
            }
          }
// declaração da função do botão calcular
          />

        </View>
        
          <Button style ={styles.calcular} onPress={this.calcular} title="Calcular"  />
          <Text style={styles.resultado}>{this.state.resultado.toFixed(2)}</Text>
          <Text style={styles.resultado}>{this.state.resultTexto}</Text>

      </View>
    );
  }
}

//area de estilização
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "lightblue",
    justifyContent: "center"
  },
  entrada: {
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center"
  },
  input: {
    height: 50,
    textAlign: "center",
    width: 240,
    height: 50,
    fontSize: 25,
    marginTop: 20,
    padding: 10,
    backgroundColor: 'white,'
  },
  resultado: {
    alignSelf: "center",
    color: "black",
    fontSize: 20,
    fontWeight: "bold",
    padding: 8
  },
  imageBackground: {
    widht:240,
    height: 120,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 20,
   
  },
  calcular:{
    marginTop: 20,
    height:40,
    widht: 120,
    color:"blue"
  }
});